<form action = "new.php" method="POST">
      <h1> Please enter your information to create a new login account</h1>
        <p>  
          <label>Login Name:</label><input type = "text"  name = "name" />
          <label>Password:</label><input type = "password" name = "pwd" />
          <br/>
          <br/>
        </p>
      <input type = "submit" name="submit_btn" id = "submit" value = "submit"/>
      <input type = "reset"  id = "reset" value = "reset"/>
    </form>